package src;

import java.util.NoSuchElementException;

public class Fila<T> {
    private static class Node<T> {
        T data;
        Node<T> next;
        Node(T data) { this.data = data; }
    }
    private Node<T> head, tail;
    private int size = 0;

    public void enfileira(T item) {
        Node<T> node = new Node<>(item);
        if (tail != null) tail.next = node;
        tail = node;
        if (head == null) head = node;
        size++;
    }
    public T desenfileira() {
        if (head == null) throw new NoSuchElementException();
        T data = head.data;
        head = head.next;
        if (head == null) tail = null;
        size--;
        return data;
    }
    public boolean estaVazia() { return size == 0; }
    public int tamanho() { return size; }
}
