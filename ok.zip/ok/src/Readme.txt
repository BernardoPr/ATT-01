Implementações próprias criadas: Array, ArrayList, Node, Pilha, Fila.

Não utilize bibliotecas prontas do Java para essas estruturas.

Se precisar usar em outros arquivos, basta importar do pacote src.
