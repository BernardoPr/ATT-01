package src;

public class Array<T> {
    private Object[] data;
    private int size;

    public Array(int capacity) {
        data = new Object[capacity];
        size = 0;
    }
    public void add(T value) {
        if (size >= data.length) throw new RuntimeException("Array cheio");
        data[size++] = value;
    }
    public T get(int index) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException();
        return (T) data[index];
    }
    public void set(int index, T value) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException();
        data[index] = value;
    }
    public int size() { return size; }
}
