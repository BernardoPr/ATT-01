package src;

import java.awt.image.BufferedImage;
import java.awt.Color;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.imageio.ImageIO;

public class Main {
    public static void main(String[] args) throws Exception {
            Scanner sc = new Scanner(System.in);
            System.out.println("Escolha o método:");
            System.out.println("1: Fila");
            System.out.println("2: Pilha");
            int metodo = sc.nextInt();
            sc.nextLine();
            File inputDir = new File("imagem/input");
            File[] files = inputDir.listFiles((d, name) -> name.endsWith(".png") || name.endsWith(".jpg"));
            if (files == null || files.length == 0) {
                System.out.println("Nenhuma imagem encontrada em imagem/input");
                return;
            }
            System.out.println("Escolha uma imagem:");
            for (int i = 0; i < files.length; i++) {
                System.out.println((i+1) + ": " + files[i].getName());
            }
            int escolha = sc.nextInt() - 1;
            BufferedImage img = ImageIO.read(files[escolha]);
            limparTerminal();
            System.out.println("Tamanho da imagem: X: "+img.getWidth() + " / Y:" + img.getHeight());
            System.out.print("Escolha um ponto X: ");
            int x = sc.nextInt();
            System.out.print("Escolha um ponto Y: ");
            int y = sc.nextInt();
            sc.nextLine(); 
            System.out.println("Pressione Enter...");
            sc.nextLine();
            limparTerminal();
            Color targetColor = new Color(img.getRGB(x, y));
            System.out.println("Escolha a cor de preenchimento:");
            System.out.println("1: Vermelho");
            System.out.println("2: Azul");
            System.out.println("3: Verde");
            int corEscolhida = sc.nextInt();
            System.out.println("colorindo ...");
            Color fillColor;
            if (corEscolhida == 1) fillColor = Color.RED;
            else if (corEscolhida == 2) fillColor = Color.BLUE;
            else fillColor = Color.GREEN;
            String outputDir = "imagem/output";
            int step = 100; // salva a cada 100 pixels coloridos
            FloodFill.fill(img, x, y, targetColor, fillColor, step, outputDir, metodo);
            List<String> imagens = new ArrayList<>();
            for (File f : new File(outputDir).listFiles()) {
                if (f.getName().startsWith("step_") && f.getName().endsWith(".png")) {
                    imagens.add(f.getPath());
                }
            }
            imagens.sort(String::compareTo);
            String gifPath = "gift/" + files[escolha].getName().replaceAll("\\..*", "") + ".gif";
            GifGenerator.createGif(imagens, gifPath);
            System.out.println("Disponível em " + gifPath);
            sc.close();
    }
    private static void limparTerminal() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }
}
