package src;

import java.util.EmptyStackException;

public class Pilha<T> {
    private static class Node<T> {
        T data;
        Node<T> next;
        Node(T data) { this.data = data; }
    }
    private Node<T> top;
    private int size = 0;

    public void empilha(T item) {
        Node<T> node = new Node<>(item);
        node.next = top;
        top = node;
        size++;
    }
    public T desempilha() {
        if (top == null) throw new EmptyStackException();
        T data = top.data;
        top = top.next;
        size--;
        return data;
    }
    public boolean estaVazia() { return size == 0; }
    public int tamanho() { return size; }
}
