package src;

import java.awt.image.BufferedImage;
import java.awt.Color;
import java.io.File;
import javax.imageio.ImageIO;

public class FloodFill {
    public static void fill(BufferedImage img, int x, int y, Color targetColor, Color fillColor, int step, String outputDir, int metodo) throws Exception {
        int width = img.getWidth();
        int height = img.getHeight();
        boolean[][] visited = new boolean[width][height];
        int count = 0;
        if (metodo == 1) { // Fila (largura)
            Fila<int[]> fila = new Fila<>();
            fila.enfileira(new int[]{x, y});
            while (!fila.estaVazia()) {
                int[] p = fila.desenfileira();
                int px = p[0], py = p[1];
                if (px < 0 || py < 0 || px >= width || py >= height) continue;
                if (visited[px][py]) continue;
                if (new Color(img.getRGB(px, py)).equals(targetColor)) {
                    img.setRGB(px, py, fillColor.getRGB());
                    visited[px][py] = true;
                    count++;
                    if (count % step == 0) {
                        ImageIO.write(img, "png", new File(outputDir + "/step_" + count + ".png"));
                    }
                    fila.enfileira(new int[]{px+1, py});
                    fila.enfileira(new int[]{px-1, py});
                    fila.enfileira(new int[]{px, py+1});
                    fila.enfileira(new int[]{px, py-1});
                }
            }
        } else { // Pilha (profundidade)
            Pilha<int[]> pilha = new Pilha<>();
            pilha.empilha(new int[]{x, y});
            while (!pilha.estaVazia()) {
                int[] p = pilha.desempilha();
                int px = p[0], py = p[1];
                if (px < 0 || py < 0 || px >= width || py >= height) continue;
                if (visited[px][py]) continue;
                if (new Color(img.getRGB(px, py)).equals(targetColor)) {
                    img.setRGB(px, py, fillColor.getRGB());
                    visited[px][py] = true;
                    count++;
                    if (count % step == 0) {
                        ImageIO.write(img, "png", new File(outputDir + "/step_" + count + ".png"));
                    }
                    pilha.empilha(new int[]{px+1, py});
                    pilha.empilha(new int[]{px-1, py});
                    pilha.empilha(new int[]{px, py+1});
                    pilha.empilha(new int[]{px, py-1});
                }
            }
        }
        ImageIO.write(img, "png", new File(outputDir + "/final.png"));
    }
}
